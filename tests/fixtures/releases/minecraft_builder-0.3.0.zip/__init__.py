"""Minecraft Builder: offline Blender UI and three schematic export formats."""
bl_info={'name':'Minecraft Builder','author':'Minecraft Builder contributors','version':(0,3,0),
         'blender':(4,2,0),'location':'3D View > Sidebar > Minecraft','category':'Import-Export'}

def register():
    from . import ui
    ui.register()
    from .perimeter import ui as perimeter_ui
    perimeter_ui.register()
    from . import live_edit
    live_edit.register()

def unregister():
    from . import live_edit
    live_edit.unregister()
    from .perimeter import ui as perimeter_ui
    perimeter_ui.unregister()
    from . import ui
    ui.unregister()
