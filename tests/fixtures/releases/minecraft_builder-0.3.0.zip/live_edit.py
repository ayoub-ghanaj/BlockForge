"""Saved block editing with small preview-chunk rebuilds and viewport tools."""
import json
import math
import bpy
import numpy as np
from bpy.props import EnumProperty,StringProperty
from bpy.app.handlers import persistent
from mathutils import Vector
from bpy_extras import view3d_utils
from . import ui,catalog
from .core import editing
from .core.shapes import orientations,with_properties,split_state,state_mask
from .core.palette import linear
from .blender_mesh import FACE_CORNERS
from .perimeter.materials import GLASS,is_glass,emission

_sessions={}
TARGETS=[('MODEL','Model',''),('PERIMETER','Perimeter','')]

def settings(context,target):return ui.palette_settings(context,target)
def root_object(context,p,target):
    tag='minecraft_builder_preview' if target=='MODEL' else 'minecraft_perimeter_generated'
    return next((o for o in context.scene.objects if o.get(tag)==p.preview_token),None)
def display(pos,target):
    x,y,z=pos
    return (x,-z,y) if target=='MODEL' else (x-1,1-z,y-1)
def canonical(pos,target):
    x,y,z=pos
    return (x,z,-y) if target=='MODEL' else (x+1,z+1,1-y)

def document(p):
    if not p.manual_edits:return editing.empty_document()
    text=p.manual_edits.as_string()
    if len(text)>32*1024*1024:raise ValueError('Saved edit layer is too large')
    data=json.loads(text)
    if data.get('schema_version')!=1 or not isinstance(data.get('patches'),dict):raise ValueError('Invalid saved edit layer')
    return data

def save_document(p,data):
    if not p.manual_edits:p.manual_edits=bpy.data.texts.new('Minecraft manual block edits')
    p.manual_edits.clear();p.manual_edits.write(json.dumps(data,separators=(',',':')))
    p.edit_count=len(data['patches'])

def material_options(p,target):
    profile,blocks=ui.chosen_blocks(p);materials={}
    for block in blocks:
        for state,_ in orientations(block):
            materials[state]=(block.rgb,block.shape)
            if block.shape=='stairs':
                for corner in ('inner_left','inner_right','outer_left','outer_right'):
                    materials[with_properties(state,shape=corner)]=(block.rgb,block.shape)
    if target=='PERIMETER':
        from .perimeter.materials import lighting_blocks
        from .perimeter.covers import KINDS,choices
        for block in (*GLASS,*lighting_blocks(profile)):materials[block.state]=(block.rgb,block.shape)
        for kind,_,_ in KINDS:
            for block in choices(profile,kind):materials[block.state]=(block.rgb,block.shape)
    return materials

def base_snapshot(p,target):
    if target=='MODEL':return ui.base_snapshot(p)
    from .perimeter import ui as perimeter_ui
    return perimeter_ui.base_snapshot(p)

def validate_current(context,p,target):
    if not p.snapshot:raise ValueError('Generate a preview first')
    from .perimeter import ui as perimeter_ui
    signature=ui.settings_signature(p) if target=='MODEL' else perimeter_ui.settings_signature(p)
    if signature!=p.snapshot_signature:raise ValueError('Settings changed; regenerate before editing blocks')
    root=root_object(context,p,target)
    if root:
        saved=root.get('minecraft_builder_basis' if target=='MODEL' else 'perimeter_basis')
        if saved and any(abs(a-b)>1e-5 for a,b in zip((v for row in root.matrix_basis.to_3x3() for v in row),saved)):
            raise ValueError('Preview was rotated/scaled; regenerate or use the preview scale checkbox')

def session(context,p,target,base=None):
    validate_current(context,p,target)
    key=(context.scene.as_pointer(),target)
    marker=(p.snapshot.as_pointer(),p.manual_edits.as_string() if p.manual_edits else '')
    if key not in _sessions or _sessions[key][0]!=marker:
        if base is None:base=base_snapshot(p,target)
        limits=(p.width,p.height,p.depth) if target=='MODEL' else (p.width+2,p.height+2,p.depth+2)
        obj=editing.Editor(base,document(p),material_options(p,target),limits,2_000_000 if target=='MODEL' else 64_000_000)
        _sessions[key]=(marker,obj)
    return _sessions[key][1]

def edited_snapshot(context,p,target,base):
    if not p.manual_edits or not document(p)['patches']:return base
    result=session(context,p,target,base).result()
    if target=='MODEL':
        from .core.exporters import validate_build,validate_profile
        validate_build(result);validate_profile(result,catalog.profiles(p)[p.target_version])
    else:
        from .perimeter.streaming import validate
        validate(result)
    return result

def new_chunk(context,root,key,vertices,polygons,materials,indices,p):
    mesh=bpy.data.meshes.new('Minecraft edit section');mesh.from_pydata(vertices,[],polygons);mesh.update()
    for material in materials:mesh.materials.append(material)
    if indices:mesh.polygons.foreach_set('material_index',indices)
    obj=bpy.data.objects.new('Blocks '+','.join(map(str,key)),mesh)
    obj.parent=root;obj['mb_edit_preview']=p.preview_token;obj['mb_edit_chunk_key']=list(key)
    root.users_collection[0].objects.link(obj)
    return obj

def chunkify(context,p,target):
    root=root_object(context,p,target)
    if not root:raise ValueError('Preview object is missing; regenerate it')
    if root.get('mb_edit_chunked'):return root
    mesh=root.data;n=len(mesh.polygons)
    if not n:raise ValueError('Preview has no geometry')
    centers=np.empty(n*3,np.float32);normals=np.empty(n*3,np.float32)
    mesh.polygons.foreach_get('center',centers);mesh.polygons.foreach_get('normal',normals)
    points=(centers-normals*1e-4).reshape(-1,3)
    points=points[:,[0,2,1]]*np.array([1,1,-1])
    if target=='PERIMETER':points+=np.array([1,1,1])
    keys=np.floor(points/16).astype(np.int32);unique,inverse=np.unique(keys,axis=0,return_inverse=True)
    coords=np.empty(len(mesh.vertices)*3,np.float32);mesh.vertices.foreach_get('co',coords);coords=coords.reshape(-1,3)
    loops=np.empty(len(mesh.loops),np.int32);mesh.loops.foreach_get('vertex_index',loops)
    totals=np.empty(n,np.int32);mesh.polygons.foreach_get('loop_total',totals)
    if not np.all(totals==4):raise ValueError('Preview mesh topology changed; regenerate it before editing')
    loops=loops.reshape(-1,4);mats=np.empty(n,np.int32);mesh.polygons.foreach_get('material_index',mats)
    created=[]
    try:
        for index,key in enumerate(unique):
            selected=np.flatnonzero(inverse==index);vertices=coords[loops[selected]].reshape(-1,3).tolist()
            used,mi=np.unique(mats[selected],return_inverse=True)
            polygons=np.arange(len(vertices)).reshape(-1,4).tolist()
            created.append(new_chunk(context,root,tuple(map(int,key)),vertices,polygons,[mesh.materials[i] for i in used],mi.tolist(),p))
        root.data=bpy.data.meshes.new('Minecraft editable preview root');root['mb_edit_chunked']=True
        if not mesh.users:bpy.data.meshes.remove(mesh)
    except Exception:
        for obj in created:
            mesh=obj.data;bpy.data.objects.remove(obj,do_unlink=True)
            if not mesh.users:bpy.data.meshes.remove(mesh)
        raise
    return root

def chunk_geometry(editor,key,target):
    low=tuple(v*16-1 for v in key);fine=np.full((36,36,36),-1,np.int32)
    states=[];ids={};glass=[];partials=[]
    for x in range(18):
        for y in range(18):
            for z in range(18):
                pos=(low[0]+x,low[1]+y,low[2]+z);state=editor.cells.get(pos)
                if state is None:continue
                if state not in ids:ids[state]=len(states);states.append(state)
                index=ids[state]
                if editor.materials[state][1]=='cover':
                    if all(1<=v<=16 for v in (x,y,z)):partials.append((pos,index))
                    continue
                if is_glass(state):
                    if all(1<=v<=16 for v in (x,y,z)):glass.append((pos,index))
                    continue
                mask=state_mask(state,editor.materials[state][1])
                for ox in range(2):
                    for oy in range(2):
                        for oz in range(2):
                            if mask&(1<<(ox+2*oz+4*oy)):fine[x*2+ox,y*2+oy,z*2+oz]=index
    occupied=fine>=0;inside=np.zeros_like(occupied);inside[2:34,2:34,2:34]=True
    vertices=[];faces=[];indices=[]
    for delta,corners in FACE_CORNERS:
        neighbor=np.roll(occupied,tuple(-d for d in delta),axis=(0,1,2))
        for coord in np.argwhere(occupied & ~neighbor & inside):
            start=len(vertices)
            vertices.extend(display(tuple(low[i]+(int(coord[i])+corner[i])/2 for i in range(3)),target) for corner in corners)
            faces.append((start,start+1,start+2,start+3));indices.append(int(fine[tuple(coord)]))
    for (x,y,z),index in glass:
        start=len(vertices);vertices.extend(display(p,target) for p in ((x,y+1,z),(x,y+1,z+1),(x+1,y+1,z+1),(x+1,y+1,z)))
        faces.append((start,start+1,start+2,start+3));indices.append(index)
    from .perimeter.covers import boxes
    for pos,index in partials:
        for bounds in boxes(states[index]):
            for delta,corners in FACE_CORNERS:
                start=len(vertices)
                vertices.extend(display(tuple(pos[i]+bounds[i]+(bounds[i+3]-bounds[i])*c[i] for i in range(3)),target) for c in corners)
                faces.append((start,start+1,start+2,start+3));indices.append(index)
    return vertices,faces,states,indices

def render_material(p,state,metadata):
    rgb,shape=metadata;key=json.dumps([list(rgb),is_glass(state),emission(state)])
    existing=next((m for m in bpy.data.materials if m.get('mb_edit_preview')==p.preview_token and m.get('mb_edit_color')==key),None)
    if existing:return existing
    mat=bpy.data.materials.new('Edit '+state.split(':')[-1]);mat['mb_edit_preview']=p.preview_token;mat['mb_edit_color']=key;mat.use_nodes=True
    rgba=tuple(linear(v/255) for v in rgb)+(0.18 if is_glass(state) else 1,)
    mat.diffuse_color=rgba;shader=mat.node_tree.nodes.get('Principled BSDF');shader.inputs['Base Color'].default_value=rgba
    shader.inputs['Alpha'].default_value=rgba[3]
    if is_glass(state):
        if hasattr(mat,'surface_render_method'):mat.surface_render_method='DITHERED'
        else:mat.blend_method='BLEND'
    if emission(state):shader.inputs['Emission Color'].default_value=rgba;shader.inputs['Emission Strength'].default_value=.5
    return mat

def refresh_chunks(context,p,target,editor,affected):
    root=chunkify(context,p,target);keys=set()
    for pos in affected:
        keys.add(tuple(v//16 for v in pos))
        for axis in range(3):
            for sign in (-1,1):
                other=list(pos);other[axis]+=sign;keys.add(tuple(v//16 for v in other))
    old={tuple(o['mb_edit_chunk_key']):o for o in root.children if 'mb_edit_chunk_key' in o}
    for key in keys:
        vertices,faces,states,indices=chunk_geometry(editor,key,target)
        if faces:new_chunk(context,root,key,vertices,faces,[render_material(p,s,editor.materials[s]) for s in states],indices,p)
        if key in old:
            obj=old[key];mesh=obj.data;bpy.data.objects.remove(obj,do_unlink=True)
            if not mesh.users:bpy.data.meshes.remove(mesh)
    p.edit_last_chunks=len(keys)

def update_cursor(p,context):
    if p.edit_cursor:
        target=p.edit_cursor.get('mb_edit_target','MODEL')
        p.edit_cursor.location=display(tuple(v+.5 for v in p.edit_position),target)

def cursor(context,p,target):
    root=root_object(context,p,target)
    if not p.edit_cursor or p.edit_cursor.parent!=root:
        obj=bpy.data.objects.new('Minecraft block cursor',None);root.users_collection[0].objects.link(obj)
        obj.parent=root;obj.empty_display_type='CUBE';obj.empty_display_size=.5;obj.show_in_front=True;obj.hide_render=True
        obj.color=(1,.5,.03,1);obj['mb_edit_preview']=p.preview_token;obj['mb_edit_cursor']=True;obj['mb_edit_target']=target
        p.edit_cursor=obj
    update_cursor(p,context)
    return p.edit_cursor

def cursor_position(p,target):
    if not p.edit_cursor:return tuple(p.edit_position)
    point=canonical(p.edit_cursor.location,target)
    return tuple(math.floor(v+1e-5) for v in point)

def brush(p,target):
    row=next((r for r in ui.eligible_rows(p) if r.name==p.edit_brush or r.state==p.edit_brush),None)
    if row is None:
        options=material_options(p,target)
        if p.edit_brush in options:return p.edit_brush
        raise ValueError('Choose an allowed block for the edit brush')
    state=row.state
    if row.shape=='slab':state=with_properties(state,type=p.edit_half)
    if row.shape=='stairs':state=with_properties(state,half=p.edit_half,facing=p.edit_facing,shape='straight')
    return state

def pick(p,editor,pos):
    p.edit_position=pos;p.edit_from=pos
    state=editor.cells.get(tuple(pos))
    if state:
        name,props=split_state(state)
        row=next((r for r in p.blocks if r.state.split('[')[0]==name),None)
        p.edit_brush=row.name if row else state
        p.edit_half=props.get('half',props.get('type','bottom')) if props.get('type')!='double' else 'bottom'
        p.edit_facing=props.get('facing','north')
    return state

def commit(context,p,target,editor,affected):
    refresh_chunks(context,p,target,editor,affected)
    save_document(p,editor.document)
    _sessions[(context.scene.as_pointer(),target)]=((p.snapshot.as_pointer(),p.manual_edits.as_string()),editor)
    p.status=f'{len(editor.cells):,} blocks · {p.edit_count} manual edits · updated {p.edit_last_chunks} sections'

def generation_finished(context,p,target):
    p.edit_enabled=False
    if not p.manual_edits:return
    doc=document(p)
    if not p.keep_manual_edits:save_document(p,editing.empty_document());return
    doc['undo']=[];doc['redo']=[];save_document(p,doc)
    if doc['patches']:
        editor=session(context,p,target)
        refresh_chunks(context,p,target,editor,{editing.position(text) for text in doc['patches'] if text not in editor.skipped})
        if editor.skipped:p.status+=f' · {len(editor.skipped)} edits skipped (outside size/palette)'

class MB_OT_edit_start(bpy.types.Operator):
    bl_idname='minecraft_builder.edit_start';bl_label='Enable Block Editing';bl_options={'REGISTER','UNDO'}
    target:EnumProperty(items=TARGETS)
    def execute(self,context):
        p=settings(context,self.target)
        try:
            editor=session(context,p,self.target);chunkify(context,p,self.target);p.edit_enabled=True
            if not p.edit_brush:
                rows=ui.eligible_rows(p)
                if rows:p.edit_brush=rows[0].name
            cursor(context,p,self.target)
            p.status='Pick or place blocks in the viewport, or use the cursor coordinates'
        except Exception as error:self.report({'ERROR'},str(error));return {'CANCELLED'}
        return {'FINISHED'}

class MB_OT_edit_action(bpy.types.Operator):
    bl_idname='minecraft_builder.edit_action';bl_label='Edit Minecraft Block';bl_options={'REGISTER','UNDO'}
    target:EnumProperty(items=TARGETS)
    action:EnumProperty(items=[(s,s.title(),'') for s in ('PICK','ADD','REPLACE','DELETE','MOVE','UNDO','REDO','CLEAR','CURSOR')])
    def execute(self,context):
        p=settings(context,self.target)
        try:
            editor=session(context,p,self.target)
            if not p.edit_cursor:cursor(context,p,self.target)
            pos=cursor_position(p,self.target);p.edit_position=pos
            if self.action=='CURSOR':
                bpy.ops.object.select_all(action='DESELECT');p.edit_cursor.select_set(True);context.view_layer.objects.active=p.edit_cursor
                return {'FINISHED'}
            if self.action=='PICK':pick(p,editor,pos);return {'FINISHED'}
            if self.action in ('UNDO','REDO'):affected=editor.undo(self.action=='REDO')
            elif self.action=='CLEAR':affected=editor.change({editing.position(s):editing.BASE for s in editor.document['patches']})
            else:
                if self.action in ('DELETE','REPLACE') and pos not in editor.cells:raise ValueError('No block at this position')
                if self.action in ('ADD','MOVE') and pos in editor.cells:raise ValueError('That position is occupied; use Replace to repaint it')
                if self.action=='MOVE':
                    source=tuple(p.edit_from)
                    if source not in editor.cells:raise ValueError('Pick a block before moving it')
                    changes={source:None,pos:editor.cells[source]}
                else:changes={pos:None if self.action=='DELETE' else brush(p,self.target)}
                affected=editor.change(changes)
                if self.action=='MOVE':p.edit_from=pos
            commit(context,p,self.target,editor,affected)
        except (ValueError,RuntimeError,KeyError) as error:
            _sessions.pop((context.scene.as_pointer(),self.target),None)
            self.report({'ERROR'},str(error));return {'CANCELLED'}
        return {'FINISHED'}

class MB_OT_edit_view(bpy.types.Operator):
    bl_idname='minecraft_builder.edit_view';bl_label='Edit Blocks in Viewport'
    target:EnumProperty(items=TARGETS)
    _drag=False;_area=None
    def invoke(self,context,event):
        if not context.area or context.area.type!='VIEW_3D':return {'CANCELLED'}
        if bpy.ops.minecraft_builder.edit_start(target=self.target)!={'FINISHED'}:return {'CANCELLED'}
        self._area=context.area;self._drag=False
        context.window_manager.modal_handler_add(self)
        self._area.header_text_set('Blocks: V pick · A add · R repaint · D delete · G drag/move · Ctrl Z undo · Esc finish. Middle mouse orbits.')
        return {'RUNNING_MODAL'}
    def finish(self):
        if self._area:self._area.header_text_set(None)
        self._drag=False
    def modal(self,context,event):
        p=settings(context,self.target)
        if event.type in ('ESC','RIGHTMOUSE') and event.value=='PRESS':self.finish();return {'FINISHED'}
        if not p.edit_enabled or not p.edit_cursor:self.finish();return {'FINISHED'}
        region=next((r for r in self._area.regions if r.type=='WINDOW'),None)
        if not region:return {'PASS_THROUGH'}
        coord=(event.mouse_x-region.x,event.mouse_y-region.y)
        if not (0<=coord[0]<region.width and 0<=coord[1]<region.height):return {'PASS_THROUGH'}
        if event.ctrl and event.type=='Z' and event.value=='PRESS':
            bpy.ops.minecraft_builder.edit_action(target=self.target,action='REDO' if event.shift else 'UNDO');return {'RUNNING_MODAL'}
        shortcuts={'V':'PICK','A':'ADD','R':'REPLACE','D':'DELETE','G':'MOVE'}
        if event.type in shortcuts and event.value=='PRESS':p.edit_mode=shortcuts[event.type];return {'RUNNING_MODAL'}
        if event.type not in ('LEFTMOUSE','MOUSEMOVE','WHEELUPMOUSE','WHEELDOWNMOUSE'):return {'PASS_THROUGH'}
        try:
            editor=session(context,p,self.target);root=root_object(context,p,self.target);rv3d=self._area.spaces.active.region_3d
            origin=view3d_utils.region_2d_to_origin_3d(region,rv3d,coord)
            direction=view3d_utils.region_2d_to_vector_3d(region,rv3d,coord)
            inverse=root.matrix_world.inverted();local_origin=canonical(inverse@origin,self.target)
            local_direction=inverse.to_3x3()@direction;local_direction=(local_direction.x,local_direction.z,-local_direction.y)
            if self._drag:
                if event.type in ('WHEELUPMOUSE','WHEELDOWNMOUSE'):
                    self._height+=1 if event.type=='WHEELUPMOUSE' else -1
                if abs(local_direction[1])>1e-8:
                    distance=(self._height+.5-local_origin[1])/local_direction[1]
                    pos=tuple(math.floor(local_origin[i]+distance*local_direction[i]) if i!=1 else self._height for i in range(3))
                    if all(0<=v<editor.limits[i] for i,v in enumerate(pos)):p.edit_position=pos
                if event.type=='LEFTMOUSE' and event.value=='RELEASE':
                    if tuple(p.edit_position)!=tuple(p.edit_from):bpy.ops.minecraft_builder.edit_action(target=self.target,action='MOVE')
                    self._drag=False
                return {'RUNNING_MODAL'}
            if event.type in ('WHEELUPMOUSE','WHEELDOWNMOUSE'):return {'PASS_THROUGH'}
            hit=editing.ray_pick(editor.cells,editor.materials,editor.limits,local_origin,local_direction,is_glass if p.edit_through_glass else None)
            if hit:
                pos,normal,state=hit
                if p.edit_mode=='ADD':pos=tuple(pos[i]+normal[i] for i in range(3))
            elif p.edit_mode=='ADD' and abs(local_direction[1])>1e-8:
                distance=(p.edit_position[1]+.5-local_origin[1])/local_direction[1]
                if distance<0:return {'RUNNING_MODAL'}
                pos=tuple(math.floor(local_origin[i]+distance*local_direction[i]) for i in range(3))
            else:return {'RUNNING_MODAL'}
            if not all(0<=v<editor.limits[i] for i,v in enumerate(pos)):return {'RUNNING_MODAL'}
            p.edit_position=pos
            if event.type=='LEFTMOUSE' and event.value=='PRESS':
                if p.edit_mode=='MOVE':pick(p,editor,pos);self._height=pos[1];self._drag=True
                else:bpy.ops.minecraft_builder.edit_action(target=self.target,action=p.edit_mode)
            self._area.tag_redraw()
        except (ValueError,RuntimeError) as error:p.status=str(error)
        return {'RUNNING_MODAL'}

def draw(box,p,target):
    box.label(text='Live block editing',icon='EDITMODE_HLT');box.prop(p,'keep_manual_edits')
    if not p.snapshot:return
    box.operator('minecraft_builder.edit_start',icon='MESH_CUBE').target=target
    if p.edit_enabled:
        box.operator('minecraft_builder.edit_view',icon='RESTRICT_SELECT_OFF').target=target
        box.prop(p,'edit_mode',text='Tool');box.prop(p,'edit_through_glass')
        box.prop_search(p,'edit_brush',p,'blocks',text='Brush block')
        row=box.row(align=True);row.prop(p,'edit_half');row.prop(p,'edit_facing')
        box.label(text='Block coordinates (Minecraft Y up)');box.prop(p,'edit_position',text='')
        op=box.operator('minecraft_builder.edit_action',text='Select cursor (G to drag)');op.action='CURSOR';op.target=target
        # Set target on every shared action, including cursor selection.
        for actions in ((('PICK','Pick at cursor'),('ADD','Add here')),(('REPLACE','Repaint'),('DELETE','Delete')),(('MOVE','Move picked block here'),)):
            row=box.row(align=True)
            for action,label in actions:
                op=row.operator('minecraft_builder.edit_action',text=label);op.action=action;op.target=target
        box.label(text='Move: drag a picked block.')
        box.label(text='Mouse wheel changes its height.')
    if p.edit_count:
        box.label(text=f'{p.edit_count} saved block edits')
        row=box.row(align=True)
        for action,label in [('UNDO','Undo edit'),('REDO','Redo edit'),('CLEAR','Clear edits')]:
            op=row.operator('minecraft_builder.edit_action',text=label);op.target=target;op.action=action
        if target=='PERIMETER':
            box.label(text='After edits, inspect cover',icon='INFO')
            box.label(text='and lighting around changed blocks.')

@persistent
def clear_cache(*args):_sessions.clear()

class MB_PT_live_edit(bpy.types.Panel):
    bl_label='Live Block Editor';bl_idname='MB_PT_live_edit';bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Minecraft';bl_order=-10
    @classmethod
    def poll(cls,context):return bool(context.scene.minecraft_builder.snapshot)
    def draw(self,context):
        p=context.scene.minecraft_builder;box=self.layout.column();box.enabled=not p.busy;draw(box,p,'MODEL')

CLASSES=(MB_OT_edit_start,MB_OT_edit_action,MB_OT_edit_view,MB_PT_live_edit)
def register():
    for cls in CLASSES:bpy.utils.register_class(cls)
    for handlers in (bpy.app.handlers.load_post,bpy.app.handlers.undo_post,bpy.app.handlers.redo_post):handlers.append(clear_cache)
def unregister():
    for handlers in (bpy.app.handlers.load_post,bpy.app.handlers.undo_post,bpy.app.handlers.redo_post):
        if clear_cache in handlers:handlers.remove(clear_cache)
    clear_cache()
    for cls in reversed(CLASSES):bpy.utils.unregister_class(cls)
