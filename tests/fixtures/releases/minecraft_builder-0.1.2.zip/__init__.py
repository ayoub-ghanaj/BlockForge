"""Minecraft Builder: offline Blender UI and three schematic export formats."""
bl_info={'name':'Minecraft Builder','author':'Minecraft Builder contributors','version':(0,1,2),
         'blender':(4,2,0),'location':'3D View > Sidebar > Minecraft','category':'Import-Export'}

def register():
    from . import ui
    ui.register()

def unregister():
    from . import ui
    ui.unregister()
